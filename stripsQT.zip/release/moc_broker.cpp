/****************************************************************************
** Meta object code from reading C++ file 'broker.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../StripsQT/src/broker.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'broker.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Broker_t {
    QByteArrayData data[30];
    char stringdata0[255];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Broker_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Broker_t qt_meta_stringdata_Broker = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Broker"
QT_MOC_LITERAL(1, 7, 14), // "updateBuilding"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 8), // "resetAll"
QT_MOC_LITERAL(4, 32, 11), // "updateStack"
QT_MOC_LITERAL(5, 44, 3), // "str"
QT_MOC_LITERAL(6, 48, 6), // "solved"
QT_MOC_LITERAL(7, 55, 11), // "updateState"
QT_MOC_LITERAL(8, 67, 11), // "std::string"
QT_MOC_LITERAL(9, 79, 3), // "msg"
QT_MOC_LITERAL(10, 83, 5), // "noSol"
QT_MOC_LITERAL(11, 89, 13), // "updateCurrent"
QT_MOC_LITERAL(12, 103, 4), // "test"
QT_MOC_LITERAL(13, 108, 9), // "getStatus"
QT_MOC_LITERAL(14, 118, 1), // "i"
QT_MOC_LITERAL(15, 120, 1), // "j"
QT_MOC_LITERAL(16, 122, 12), // "getBoardSize"
QT_MOC_LITERAL(17, 135, 10), // "resetBoard"
QT_MOC_LITERAL(18, 146, 9), // "addObject"
QT_MOC_LITERAL(19, 156, 6), // "firstX"
QT_MOC_LITERAL(20, 163, 6), // "firstY"
QT_MOC_LITERAL(21, 170, 4), // "secX"
QT_MOC_LITERAL(22, 175, 4), // "secY"
QT_MOC_LITERAL(23, 180, 5), // "index"
QT_MOC_LITERAL(24, 186, 10), // "whichBoard"
QT_MOC_LITERAL(25, 197, 9), // "copyBoard"
QT_MOC_LITERAL(26, 207, 10), // "printBoard"
QT_MOC_LITERAL(27, 218, 12), // "beginSolving"
QT_MOC_LITERAL(28, 231, 11), // "setResetReq"
QT_MOC_LITERAL(29, 243, 11) // "togglePause"

    },
    "Broker\0updateBuilding\0\0resetAll\0"
    "updateStack\0str\0solved\0updateState\0"
    "std::string\0msg\0noSol\0updateCurrent\0"
    "test\0getStatus\0i\0j\0getBoardSize\0"
    "resetBoard\0addObject\0firstX\0firstY\0"
    "secX\0secY\0index\0whichBoard\0copyBoard\0"
    "printBoard\0beginSolving\0setResetReq\0"
    "togglePause"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Broker[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   99,    2, 0x06 /* Public */,
       3,    0,  100,    2, 0x06 /* Public */,
       4,    1,  101,    2, 0x06 /* Public */,
       6,    0,  104,    2, 0x06 /* Public */,
       7,    1,  105,    2, 0x06 /* Public */,
      10,    0,  108,    2, 0x06 /* Public */,
      11,    0,  109,    2, 0x06 /* Public */,

 // methods: name, argc, parameters, tag, flags
      12,    0,  110,    2, 0x02 /* Public */,
      13,    3,  111,    2, 0x02 /* Public */,
      16,    0,  118,    2, 0x02 /* Public */,
      17,    0,  119,    2, 0x02 /* Public */,
      18,    6,  120,    2, 0x02 /* Public */,
      25,    0,  133,    2, 0x02 /* Public */,
      26,    0,  134,    2, 0x02 /* Public */,
      27,    0,  135,    2, 0x02 /* Public */,
      28,    0,  136,    2, 0x02 /* Public */,
      29,    0,  137,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::Void,
    QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   14,   15,    2,
    QMetaType::Int,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   19,   20,   21,   22,   23,   24,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Broker::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Broker *_t = static_cast<Broker *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateBuilding(); break;
        case 1: _t->resetAll(); break;
        case 2: _t->updateStack((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->solved(); break;
        case 4: _t->updateState((*reinterpret_cast< std::string(*)>(_a[1]))); break;
        case 5: _t->noSol(); break;
        case 6: _t->updateCurrent(); break;
        case 7: _t->test(); break;
        case 8: { int _r = _t->getStatus((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 9: { int _r = _t->getBoardSize();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 10: _t->resetBoard(); break;
        case 11: _t->addObject((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6]))); break;
        case 12: _t->copyBoard(); break;
        case 13: _t->printBoard(); break;
        case 14: _t->beginSolving(); break;
        case 15: _t->setResetReq(); break;
        case 16: _t->togglePause(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::updateBuilding)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::resetAll)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (Broker::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::updateStack)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::solved)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (Broker::*_t)(std::string );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::updateState)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::noSol)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::updateCurrent)) {
                *result = 6;
                return;
            }
        }
    }
}

const QMetaObject Broker::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Broker.data,
      qt_meta_data_Broker,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Broker::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Broker::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Broker.stringdata0))
        return static_cast<void*>(const_cast< Broker*>(this));
    return QObject::qt_metacast(_clname);
}

int Broker::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 17;
    }
    return _id;
}

// SIGNAL 0
void Broker::updateBuilding()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void Broker::resetAll()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void Broker::updateStack(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Broker::solved()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void Broker::updateState(std::string _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Broker::noSol()
{
    QMetaObject::activate(this, &staticMetaObject, 5, Q_NULLPTR);
}

// SIGNAL 6
void Broker::updateCurrent()
{
    QMetaObject::activate(this, &staticMetaObject, 6, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
