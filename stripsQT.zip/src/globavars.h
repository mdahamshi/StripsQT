#ifndef GLOBAVARS_H
#define GLOBAVARS_H
#include "building.h"

extern Building buildingBoard ;
extern Building desiredBoard ;

#endif // GLOBAVARS_H
