#include "roam.h"



Roam::Roam()
{

}
Roam::Roam(Point a, Point b, int c):Furniture(a,b,c)
{

}
