#ifndef SOLVER_H
#define SOLVER_H


class Solver
{
public:
    Solver();
};

#endif // SOLVER_H