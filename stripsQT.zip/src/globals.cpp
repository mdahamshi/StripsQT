#include "globals.h"

Globals::Globals()
{

}
